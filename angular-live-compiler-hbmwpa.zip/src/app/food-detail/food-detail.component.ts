import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FoodService } from '../food.service';
@Component({
 selector: 'app-food-detail',
 templateUrl: './food-detail.component.html',
 styleUrls: ['./food-detail.component.css']
})
export class FoodDetailComponent implements OnInit {
 food: any;
 constructor(
   private route: ActivatedRoute,
   private foodService: FoodService
 ) { }
 ngOnInit(): void {
   const id = +this.route.snapshot.paramMap.get('id');
   this.foodService.getFood(id).subscribe(data => {
     this.food = data;
   });
 }
}