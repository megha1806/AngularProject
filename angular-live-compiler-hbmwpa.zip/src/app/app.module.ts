import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component'; // Import the root component
import { FoodListComponent } from './food-list/food-list.component'; // Import other components
import { FoodDetailComponent } from './food-detail/food-detail.component';
import { SearchBarComponent } from './search-bar/search-bar.component';
import { FilterPipe } from './filter.pipe';
@NgModule({
 declarations: [
   AppComponent, // Declare the root component and other components
   FoodListComponent,
   FoodDetailComponent,
   SearchBarComponent,
   FilterPipe
 ],
 imports: [
   BrowserModule,
   AppRoutingModule,
   HttpClientModule,
   FormsModule
 ],
 providers: [],
 bootstrap: [AppComponent] // Bootstrap the root component
})
export class AppModule { }