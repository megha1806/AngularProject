import { Component, OnInit } from '@angular/core';
import { FoodService } from '../food.service';
@Component({
 selector: 'app-food-list',
 templateUrl: './food-list.component.html',
 styleUrls: ['./food-list.component.css']
})
export class FoodListComponent implements OnInit {
 foods: any[] = [];         // Array to hold the list of food items
 searchQuery: string = '';  // String to hold the search query
 constructor(private foodService: FoodService) { }
 ngOnInit(): void {
   this.loadFoods();
 }
 loadFoods(): void {
   this.foodService.getFoods().subscribe(data => {
     this.foods = data.recipes; // Adjust based on actual API response structure
   });
 }
 searchFoods(): void {
   // If the search logic is more complex, handle it here or integrate with the service
   // For now, the `filter` pipe in the template handles basic filtering
 }
}