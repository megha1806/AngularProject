import { Component } from '@angular/core';
@Component({
 selector: 'app-root', // Ensure this matches your HTML
 templateUrl: './app.component.html',
 styleUrls: ['./app.component.css']
})
export class AppComponent {
 title = 'food-recipes-app';
}